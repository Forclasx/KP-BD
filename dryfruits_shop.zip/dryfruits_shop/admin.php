<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения к базе: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>АДМИНКА - ЦАРСТВО СУХОФРУКТОВ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body {
            background: #000;
            color: #ffcc00;
            font-family: 'Bebas Neue', sans-serif;
            padding: 20px;
            margin: 0;
            overflow-x: hidden;
        }

        h1, h2 {
            font-size: 4em;
            text-align: center;
            text-shadow: 0 0 15px #ff6b00;
            color: #ffcc00;
            animation: glow 2s infinite;
        }

        .controls {
            max-width: 800px;
            margin: 20px auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search-box, .sort-box {
            background: rgba(255, 107, 0, 0.2);
            padding: 10px;
            border: 2px solid #ff6b00;
            border-radius: 10px;
        }

        input[type="text"], select {
            padding: 10px;
            background: #333;
            border: 2px solid #ffcc00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
        }

        form[name="add-form"] {
            max-width: 500px;
            margin: 20px auto;
            background: rgba(255, 107, 0, 0.2);
            padding: 20px;
            border: 3px solid #ff6b00;
            border-radius: 15px;
            box-shadow: 0 0 20px #ff6b00;
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #333;
            border: 2px solid #ff6b00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="file"] { background: none; border: none; }

        input[type="submit"], button {
            background: #ff6b00;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
            padding: 10px 20px;
            font-size: 1.2em;
            border-radius: 10px;
        }

        input[type="submit"]:hover, button:hover {
            background: #ffcc00;
            color: #000;
        }

        .product-list, .order-list, .contact-list {
            max-width: 1000px;
            margin: 20px auto;
        }

        .product-item, .order-item, .contact-item {
            background: rgba(255, 107, 0, 0.3);
            padding: 15px;
            margin: 15px 0;
            border: 3px solid #ffcc00;
            border-radius: 15px;
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .product-item:hover, .order-item:hover, .contact-item:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px #ff6b00;
        }

        .product-item img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            border-radius: 10px;
            border: 2px solid #ff6b00;
        }

        .product-info, .order-info, .contact-info { flex-grow: 1; }

        .product-info h3, .order-info h3, .contact-info h3 {
            margin: 0;
            font-size: 2em;
            color: #ffcc00;
        }

        .product-info p, .order-info p, .contact-info p {
            margin: 5px 0;
            font-size: 1.2em;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .delete-btn { background: #ff0000; }
        .delete-btn:hover { background: #ff6666; }

        .status-btn { background: #00ff00; }
        .status-btn:hover { background: #00cc00; }

        @keyframes glow {
            0% { text-shadow: 0 0 10px #ff6b00; }
            50% { text-shadow: 0 0 20px #ffcc00; }
            100% { text-shadow: 0 0 10px #ff6b00; }
        }
    </style>
</head>
<body>
    <h1>АДМИНКА - ЦАРСТВО СУХОФРУКТОВ</h1>
    <div style="text-align: center; margin-bottom: 20px;">
        <form method='POST' action='login.php'>
            <input type='hidden' name='logout' value='1'>
            <input type='submit' value='ВЫЙТИ' style='background: #ff0000; padding: 10px 20px; border: none; border-radius: 10px; cursor: pointer;'>
        </form>
        <form method='GET' action='index.php'>
            <input type='submit' value='НА ГЛАВНУЮ' style='background: #ff6b00; padding: 10px 20px; border: none; border-radius: 10px; cursor: pointer; margin-left: 10px;'>
        </form>
    </div>

    <!-- Поиск и сортировка товаров -->
    <div class="controls">
        <div class="search-box">
            <form method="GET">
                <input type="text" name="search" placeholder="Поиск по названию" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <input type="submit" value="НАЙТИ">
            </form>
        </div>
        <div class="sort-box">
            <form method="GET">
                <select name="sort" onchange="this.form.submit()">
                    <option value="name_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_asc') ? 'selected' : ''; ?>>Название (А-Я)</option>
                    <option value="name_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_desc') ? 'selected' : ''; ?>>Название (Я-А)</option>
                    <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>Цена (по возрастанию)</option>
                    <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>Цена (по убыванию)</option>
                </select>
            </form>
        </div>
    </div>

    <!-- Форма добавления -->
    <form name="add-form" method="POST" action="" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Название фрукта" required>
        <input type="number" name="price" placeholder="Цена (руб.)" step="0.01" required>
        <input type="number" name="stock" placeholder="Количество на складе" required>
        <textarea name="description" placeholder="Описание (опционально)"></textarea>
        <input type="file" name="image" accept="image/*">
        <input type="submit" name="add" value="ДОБАВИТЬ  ФРУКТ">
    </form>

    <div class="product-list">
        <?php
        // Обработка добавления
        if (isset($_POST['add'])) {
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $price = floatval($_POST['price']);
            $stock = intval($_POST['stock']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $image = '';

            if (!empty($_FILES['image']['name'])) {
                $target_dir = "images/";
                $file_name = basename($_FILES["image"]["name"]);
                $target_file = $target_dir . time() . "_" . $file_name;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                if ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg") {
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        $image = $target_file;
                    }
                }
            }

            $query = "INSERT INTO products (name, price, stock, description, image) 
                      VALUES ('$name', $price, $stock, '$description', '$image')";
            if (mysqli_query($conn, $query)) {
                echo "<p style='text-align: center; color: #ff6b00;'>ФРУКТ ДОБАВЛЕН, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        // Обработка редактирования
        if (isset($_POST['edit'])) {
            $id = intval($_POST['id']);
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $price = floatval($_POST['price']);
            $stock = intval($_POST['stock']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $image_query = '';

            if (!empty($_FILES['image']['name'])) {
                $target_dir = "images/";
                $file_name = basename($_FILES["image"]["name"]);
                $target_file = $target_dir . time() . "_" . $file_name;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
                if ($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg") {
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        $image_query = ", image = '$target_file'";
                    }
                }
            }

            $query = "UPDATE products SET name = '$name', price = $price, stock = $stock, description = '$description' $image_query WHERE id = $id";
            if (mysqli_query($conn, $query)) {
                echo "<p style='text-align: center; color: #ff6b00;'>ФРУКТ ОБНОВЛЁН, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        // Обработка удаления
        if (isset($_POST['delete'])) {
            $id = intval($_POST['id']);
            $query = "DELETE FROM products WHERE id = $id";
            if (mysqli_query($conn, $query)) {
                echo "<p style='text-align: center; color: #ff6b00;'>ФРУКТ УНИЧТОЖЕН, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        // Обработка выхода
        if (isset($_POST['logout'])) {
            session_destroy();
            header("Location: login.php");
            exit();
        }

        // Поиск и сортировка товаров
        $where = "";
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search = mysqli_real_escape_string($conn, $_GET['search']);
            $where = "WHERE name LIKE '%$search%'";
        }

        $order = "ORDER BY name ASC";
        if (isset($_GET['sort'])) {
            switch ($_GET['sort']) {
                case 'name_asc': $order = "ORDER BY name ASC"; break;
                case 'name_desc': $order = "ORDER BY name DESC"; break;
                case 'price_asc': $order = "ORDER BY price ASC"; break;
                case 'price_desc': $order = "ORDER BY price DESC"; break;
            }
        }

        // Вывод списка товаров
        $result = mysqli_query($conn, "SELECT * FROM products $where $order");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<form method='POST' enctype='multipart/form-data' class='product-item'>";
            echo "<img src='" . ($row['image'] ?: 'images/default.png') . "' alt='" . $row['name'] . "'>";
            echo "<div class='product-info'>";
            echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
            echo "<input type='text' name='name' value='" . htmlspecialchars($row['name']) . "' required>";
            echo "<input type='number' name='price' value='" . $row['price'] . "' step='0.01' required>";
            echo "<input type='number' name='stock' value='" . $row['stock'] . "' required>";
            echo "<textarea name='description'>" . htmlspecialchars($row['description']) . "</textarea>";
            echo "<input type='file' name='image' accept='image/*'>";
            echo "</div>";
            echo "<div class='actions'>";
            echo "<input type='submit' name='edit' value='РЕДАКТИРОВАТЬ'>";
            echo "<input type='submit' name='delete' value='УДАЛИТЬ' class='delete-btn'>";
            echo "</div>";
            echo "</form>";
        }
        ?>
    </div>

    <h2 style="text-align: center; margin-top: 40px;">ЗАКАЗЫ, БРО</h2>
    <div class="order-list">
        <?php
        // Обработка удаления заказов
        if (isset($_POST['delete_order'])) {
            $order_id = intval($_POST['order_id']);
            $query = "DELETE FROM orders WHERE id = $order_id";
            if (mysqli_query($conn, $query)) {
                mysqli_query($conn, "DELETE FROM order_items WHERE order_id = $order_id");
                echo "<p style='text-align: center; color: #ff6b00;'>ЗАКАЗ УДАЛЁН, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        // Обработка изменения статуса
        if (isset($_POST['update_status'])) {
            $order_id = intval($_POST['order_id']);
            $status = mysqli_real_escape_string($conn, $_POST['status']);
            $query = "UPDATE orders SET status = '$status' WHERE id = $order_id";
            if (mysqli_query($conn, $query)) {
                echo "<p style='text-align: center; color: #ff6b00;'>СТАТУС ОБНОВЛЁН, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        $order_result = mysqli_query($conn, "SELECT orders.id, orders.total_amount, orders.status, orders.created_at, orders.first_name, orders.last_name, orders.address, orders.phone, users.username 
            FROM orders 
            JOIN users ON orders.user_id = users.id 
            ORDER BY orders.created_at DESC");
        while ($order = mysqli_fetch_assoc($order_result)) {
            echo "<form method='POST' class='order-item'>";
            echo "<div class='order-info'>";
            echo "<h3>Заказ #" . $order['id'] . "</h3>";
            echo "<p>Пользователь: " . $order['username'] . "</p>";
            echo "<p>Имя: " . $order['first_name'] . "</p>";
            echo "<p>Фамилия: " . $order['last_name'] . "</p>";
            echo "<p>Адрес: " . $order['address'] . "</p>";
            echo "<p>Телефон: " . $order['phone'] . "</p>";
            echo "<p>Сумма: " . $order['total_amount'] . " руб.</p>";
            echo "<p>Статус: ";
            echo "<select name='status'>";
            $statuses = ['В ожидании', 'В обработке', 'Готов', 'Оплачен', 'Завершён', 'Отменён'];
            foreach ($statuses as $s) {
                echo "<option value='$s' " . ($order['status'] == $s ? 'selected' : '') . ">$s</option>";
            }
            echo "</select>";
            echo "</p>";
            echo "<p>Дата: " . $order['created_at'] . "</p>";
            echo "<input type='hidden' name='order_id' value='" . $order['id'] . "'>";
            echo "<div class='actions'>";
            echo "<input type='submit' name='update_status' value='ОБНОВИТЬ СТАТУС' class='status-btn'>";
            echo "<input type='submit' name='delete_order' value='УДАЛИТЬ' class='delete-btn'>";
            echo "</div>";
            echo "</div>";
            echo "</form>";

            // Детали заказа
            $items_result = mysqli_query($conn, "SELECT order_items.quantity, products.name, order_items.price 
                FROM order_items 
                JOIN products ON order_items.product_id = products.id 
                WHERE order_items.order_id = " . $order['id']);
            echo "<div style='margin-left: 140px; padding-left: 20px;'>";
            while ($item = mysqli_fetch_assoc($items_result)) {
                echo "<p>" . $item['name'] . " - " . $item['quantity'] . " шт. - " . ($item['price'] * $item['quantity']) . " руб.</p>";
            }
            echo "</div>";
        }
        if (mysqli_num_rows($order_result) == 0) {
            echo "<p style='text-align: center;'>Заказов нет, бро!</p>";
        }
        ?>

        <!-- Кнопка экспорта в PDF -->
        <div style="text-align: center; margin-top: 20px;">
            <form method="POST" action="export_orders.php">
                <input type="submit" value="ЭКСПОРТ ЗАКАЗОВ В PDF" style='background: #00ff00; padding: 10px 20px; border: none; border-radius: 10px; cursor: pointer;'>
            </form>
        </div>
    </div>

    <h2 style="text-align: center; margin-top: 40px;">СООБЩЕНИЯ С ОБРАТНОЙ СВЯЗИ, БРО</h2>
    <div class="contact-list">
        <?php
        // Обработка удаления сообщения
        if (isset($_POST['delete_contact'])) {
            $contact_id = intval($_POST['contact_id']);
            $query = "DELETE FROM contacts WHERE id = $contact_id";
            if (mysqli_query($conn, $query)) {
                echo "<p style='text-align: center; color: #ff6b00;'>СООБЩЕНИЕ УДАЛЕНО, БРО!</p>";
            } else {
                echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
            }
        }

        // Вывод сообщений
        $contact_result = mysqli_query($conn, "SELECT * FROM contacts ORDER BY created_at DESC");
        while ($contact = mysqli_fetch_assoc($contact_result)) {
            echo "<form method='POST' class='contact-item'>";
            echo "<div class='contact-info'>";
            echo "<h3>Сообщение от " . $contact['name'] . "</h3>";
            echo "<p>Email: " . $contact['email'] . "</p>";
            echo "<p>Сообщение: " . htmlspecialchars($contact['message']) . "</p>";
            echo "<p>Дата: " . $contact['created_at'] . "</p>";
            echo "<input type='hidden' name='contact_id' value='" . $contact['id'] . "'>";
            echo "<div class='actions'>";
            echo "<input type='submit' name='delete_contact' value='УДАЛИТЬ' class='delete-btn'>";
            echo "</div>";
            echo "</div>";
            echo "</form>";
        }
        if (mysqli_num_rows($contact_result) == 0) {
            echo "<p style='text-align: center;'>Сообщений нет, бро!</p>";
        }
        ?>

        
    </div>

    <?php mysqli_close($conn); ?>
</body>
</html>