<?php
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;

$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

mysqli_query($conn, "DELETE FROM cart WHERE user_id = $user_id");
mysqli_close($conn);
header("Location: index.php");
exit();
?>