<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>ЛИЧНЫЙ КАБИНЕТ - ПАЦАНЫ НА СУХОФРУКТАХ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body {
            background: #000;
            color: #ffcc00;
            font-family: 'Bebas Neue', sans-serif;
            padding: 20px;
            margin: 0;
        }
        header {
            background: rgba(0, 0, 0, 0.9);
            padding: 20px;
            text-align: center;
            border-bottom: 3px solid #ff6b00;
            box-shadow: 0 0 20px #ff6b00;
        }
        header h1 { font-size: 3em; margin: 0; color: #ffcc00; text-shadow: 0 0 10px #ff6b00; animation: pulse 2s infinite; }
        nav { margin-top: 10px; }
        nav a { color: #ffcc00; font-size: 1.5em; margin: 0 20px; text-decoration: none; transition: color 0.3s; }
        nav a:hover { color: #ff6b00; }
        .profile-box {
            max-width: 800px;
            margin: 20px auto;
            background: rgba(255, 107, 0, 0.2);
            padding: 20px;
            border: 3px solid #ff6b00;
            border-radius: 15px;
            box-shadow: 0 0 20px #ff6b00;
        }
        .order-item {
            background: rgba(255, 107, 0, 0.3);
            padding: 15px;
            margin: 15px 0;
            border: 3px solid #ffcc00;
            border-radius: 15px;
            transition: transform 0.3s;
        }
        .order-item:hover { transform: scale(1.05); box-shadow: 0 0 30px #ff6b00; }
        h2 { font-size: 2.5em; text-align: center; text-shadow: 0 0 10px #ff6b00; }
        p { font-size: 1.2em; margin: 5px 0; }
        .actions { text-align: center; margin-top: 20px; }
        .actions a { color: #ffcc00; font-size: 1.2em; margin: 0 10px; text-decoration: none; }
        .actions a:hover { color: #ff6b00; }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <header>
        <h1>ЛИЧНЫЙ КАБИНЕТ - ПАЦАНЫ НА СУХОФРУКТАХ</h1>
        <nav>
            <a href="index.php">ГЛАВНАЯ</a>
            <a href="logout_user.php">ВЫЙТИ (<?php echo $_SESSION['username']; ?>)</a>
        </nav>
    </header>

    <div class="profile-box">
        <h2>ТВОИ ЗАКАЗЫ, БРО</h2>
        <?php
        $order_result = mysqli_query($conn, "SELECT orders.id, orders.total_amount, orders.status, orders.created_at, orders.first_name, orders.last_name, orders.address, orders.phone 
            FROM orders 
            WHERE user_id = $user_id 
            ORDER BY orders.created_at DESC");
        if (mysqli_num_rows($order_result) > 0) {
            while ($order = mysqli_fetch_assoc($order_result)) {
                echo "<div class='order-item'>";
                echo "<h3>Заказ #" . $order['id'] . "</h3>";
                echo "<p>Сумма: " . $order['total_amount'] . " руб.</p>";
                echo "<p>Статус: " . $order['status'] . "</p>";
                echo "<p>Имя: " . $order['first_name'] . "</p>";
                echo "<p>Фамилия: " . $order['last_name'] . "</p>";
                echo "<p>Адрес: " . $order['address'] . "</p>";
                echo "<p>Телефон: " . $order['phone'] . "</p>";
                echo "<p>Дата: " . $order['created_at'] . "</p>";

                // Детали заказа
                $items_result = mysqli_query($conn, "SELECT order_items.quantity, products.name, order_items.price 
                    FROM order_items 
                    JOIN products ON order_items.product_id = products.id 
                    WHERE order_items.order_id = " . $order['id']);
                echo "<h4>Товары в заказе:</h4>";
                while ($item = mysqli_fetch_assoc($items_result)) {
                    echo "<p>" . $item['name'] . " - " . $item['quantity'] . " шт. - " . ($item['price'] * $item['quantity']) . " руб.</p>";
                }
                echo "</div>";
            }
        } else {
            echo "<p>У тебя нет заказов, бро! <a href='index.php'>Сделай покупку</a></p>";
        }
        mysqli_close($conn);
        ?>
    </div>
</body>
</html>