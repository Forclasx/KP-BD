<?php
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;

$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['confirm_order'])) {
        // Получаем данные из формы
        $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);

        // Убираем все пробелы, скобки и тире для проверки
        $clean_phone = preg_replace('/[\s\(\)-]/', '', $phone);
        // Проверка формата номера (гибкая: только +375 и 9 цифр после)
        if (!preg_match('/^\+375\d{9}$/', $clean_phone)) {
            echo "<p style='text-align: center; color: red;'>Неверный формат телефона! Используйте +375 и 9 цифр (например, +375297867892)</p>";
            mysqli_close($conn);
            exit();
        }

        // Сохраняем отформатированный номер (с пробелами и скобками) для отображения
        $formatted_phone = $phone;

        // Получаем содержимое корзины с ценой и количеством из products
        $cart_result = mysqli_query($conn, "SELECT cart.product_id, cart.quantity, products.price, products.stock 
            FROM cart 
            JOIN products ON cart.product_id = products.id 
            WHERE cart.user_id = $user_id");
        $total_amount = 0;

        while ($item = mysqli_fetch_assoc($cart_result)) {
            $total_amount += $item['quantity'] * $item['price'];
            $product_id = $item['product_id'];
            $ordered_quantity = $item['quantity'];
            $current_stock = $item['stock'];

            // Проверяем, достаточно ли товара на складе
            if ($current_stock < $ordered_quantity) {
                echo "<p style='text-align: center; color: red;'>Недостаточно товара '" . $item['name'] . "' на складе! Доступно: " . $current_stock . "</p>";
                mysqli_close($conn);
                exit();
            }

            // Обновляем количество на складе (уменьшаем)
            $new_stock = $current_stock - $ordered_quantity;
            mysqli_query($conn, "UPDATE products SET stock = $new_stock WHERE id = $product_id");
        }

        // Создаём заказ
        $query = "INSERT INTO orders (user_id, total_amount, status, first_name, last_name, address, phone) 
                  VALUES ($user_id, $total_amount, 'В ожидании', '$first_name', '$last_name', '$address', '$formatted_phone')";
        if (mysqli_query($conn, $query)) {
            $order_id = mysqli_insert_id($conn);

            // Добавляем элементы заказа
            mysqli_data_seek($cart_result, 0); // Сбрасываем указатель результата
            while ($item = mysqli_fetch_assoc($cart_result)) {
                $product_id = $item['product_id'];
                $quantity = $item['quantity'];
                $price = $item['price'];
                mysqli_query($conn, "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($order_id, $product_id, $quantity, $price)");
            }

            // Очищаем корзину
            mysqli_query($conn, "DELETE FROM cart WHERE user_id = $user_id");
            echo "<p style='text-align: center; color: #ff6b00;'>ЗАКАЗ ОФОРМЛЕН, БРО!</p>";
        } else {
            echo "<p style='text-align: center; color: red;'>ОШИБКА: " . mysqli_error($conn) . "</p>";
        }
    }
} else {
    $cart_result = mysqli_query($conn, "SELECT cart.quantity, products.name, products.price 
        FROM cart 
        JOIN products ON cart.product_id = products.id 
        WHERE cart.user_id = $user_id");
    $total_amount = 0;
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>ОФОРМЛЕНИЕ ЗАКАЗА</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body {
            background: #000;
            color: #ffcc00;
            font-family: 'Bebas Neue', sans-serif;
            padding: 20px;
            margin: 0;
        }
        .checkout-box {
            max-width: 600px;
            margin: 20px auto;
            background: rgba(255, 107, 0, 0.2);
            padding: 40px;
            border: 3px solid #ff6b00;
            border-radius: 15px;
            box-shadow: 0 0 20px #ff6b00;
        }
        h1 { font-size: 3em; text-align: center; text-shadow: 0 0 10px #ff6b00; }
        p { font-size: 1.2em; margin: 10px 0; }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #333;
            border: 2px solid #ff6b00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
        }
        input[type="tel"] {
            background: #333;
            border: 2px solid #ff6b00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
            padding-left: 10px; /* Отступ для placeholder */
        }
        input[type="tel"]:focus {
            outline: none;
            border-color: #ffcc00;
            box-shadow: 0 0 10px #ff6b00;
        }
        input[type="submit"] {
            background: #00ff00;
            border: none;
            padding: 15px 30px;
            color: #000;
            font-size: 1.5em;
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.3s;
        }
        input[type="submit"]:hover { background: #00cc00; }
        a { color: #ffcc00; text-decoration: none; font-size: 1.2em; }
        a:hover { color: #ff6b00; }
    </style>
</head>
<body>
    <div class="checkout-box">
        <h1>ОФОРМЛЕНИЕ ЗАКАЗА</h1>
        <?php if (mysqli_num_rows($cart_result) > 0): ?>
            <p>Ваша корзина:</p>
            <?php while ($item = mysqli_fetch_assoc($cart_result)): ?>
                <p><?php echo $item['name']; ?> - <?php echo $item['quantity']; ?> шт. - <?php echo ($item['price'] * $item['quantity']); ?> руб.</p>
                <?php $total_amount += $item['price'] * $item['quantity']; ?>
            <?php endwhile; ?>
            <p>Итого: <?php echo $total_amount; ?> руб.</p>
            <form method="POST">
                <input type="text" name="first_name" placeholder="Имя" required>
                <input type="text" name="last_name" placeholder="Фамилия" required>
                <input type="text" name="address" placeholder="Адрес доставки" required>
                <input type="tel" name="phone" placeholder="+375297867892" id="phoneInput" required>
                <input type="submit" name="confirm_order" value="ОФОРМИТЬ">
            </form>
        <?php else: ?>
            <p>Корзина пуста, бро! <a href="index.php">Вернись к покупкам</a></p>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById('phoneInput').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // Убираем все нецифры
            if (value.startsWith('375')) {
                value = value.substring(3); // Убираем 375, если пользователь ввёл его
            }
            if (value.length > 9) value = value.substring(0, 9); // Ограничиваем до 9 цифр после +375

            let formatted = '+375 ';
            if (value.length > 0) formatted += '(' + value.substring(0, 2) + ') ';
            if (value.length > 2) formatted += value.substring(2, 5) + '-';
            if (value.length > 5) formatted += value.substring(5, 7) + '-';
            if (value.length > 7) formatted += value.substring(7, 9);

            e.target.value = formatted;
        });
    </script>
</body>
</html>

<?php
}
mysqli_close($conn);
?>