<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>КОНТАКТЫ - СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body { 
            margin: 0; 
            padding: 0; 
            background: linear-gradient(45deg, #ff6b00, #ffcc00, #ff6b00); 
            font-family: 'Bebas Neue', sans-serif; 
            color: #fff; 
            overflow-x: hidden; 
            position: relative;
        }

        header { 
            background: rgba(0, 0, 0, 0.9); 
            padding: 20px; 
            text-align: center; 
            border-bottom: 3px solid #ff6b00; 
            box-shadow: 0 0 20px #ff6b00;
        }

        .logo { 
            font-size: 4em; 
            color: #ff6b00; 
            text-shadow: 5px 5px 10px #ffcc00; 
            font-weight: bold; 
            animation: pulse 2s infinite;
        }

        nav { 
            margin-top: 20px; 
        }
        nav a { 
            color: #ffcc00; 
            font-size: 1.5em; 
            margin: 0 20px; 
            text-decoration: none; 
            transition: color 0.3s; 
        }
        nav a:hover { 
            color: #ff6b00; 
        }

        .contacts-content { 
            max-width: 1000px; 
            margin: 20px auto; 
            background: rgba(0, 0, 0, 0.7); 
            padding: 40px; 
            border: 3px solid #ff6b00; 
            border-radius: 15px; 
            box-shadow: 0 0 30px #ff6b00;
        }
        .contacts-content h1 { 
            font-size: 4em; 
            text-align: center; 
            text-shadow: 0 0 15px #ffcc00; 
            margin-bottom: 20px; 
        }
        .contacts-content p { 
            font-size: 1.5em; 
            line-height: 1.6; 
            margin-bottom: 20px; 
        }
        .contact-info { 
            margin: 20px 0; 
        }
        .contact-info p { 
            font-size: 1.5em; 
            margin: 10px 0; 
        }
        .map { 
            width: 100%; 
            height: 400px; 
            margin: 20px 0; 
            border: 3px solid #ff6b00; 
            border-radius: 15px; 
            box-shadow: 0 0 30px #ff6b00;
        }
        .contact-form { 
            margin-top: 20px; 
        }
        .contact-form input, .contact-form textarea { 
            width: 100%; 
            padding: 10px; 
            margin: 10px 0; 
            background: #333; 
            border: 2px solid #ff6b00; 
            color: #fff; 
            font-size: 1.2em; 
            border-radius: 5px; 
        }
        .contact-form input[type="submit"] { 
            background: #ff6b00; 
            border: none; 
            padding: 15px 30px; 
            color: #fff; 
            font-size: 1.5em; 
            border-radius: 10px; 
            cursor: pointer; 
            transition: background 0.3s; 
        }
        .contact-form input[type="submit"]:hover { 
            background: #ffcc00; 
            color: #000; 
        }

        @keyframes pulse { 
            0% { transform: scale(1); } 
            50% { transform: scale(1.05); } 
            100% { transform: scale(1); } 
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</div>
        <nav>
            <a href="index.php">ГЛАВНАЯ</a>
            <a href="about.php">О НАС</a>
            <a href="contacts.php">КОНТАКТЫ</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="user_profile.php">ЛИЧНЫЙ КАБИНЕТ</a>
                <a href="logout_user.php">ВЫЙТИ (<?php echo $_SESSION['username']; ?>)</a>
            <?php else: ?>
                <a href="login_user.php">ВХОД</a>
                <a href="register.php">РЕГИСТРАЦИЯ</a>
            <?php endif; ?>
            <a href="admin.php">АДМИНКА</a>
        </nav>
    </header>

    <div class="contacts-content">
        <h1>КОНТАКТЫ - СВЯЖИСЬ С НАМИ, БРО!</h1>
        <div class="contact-info">
            <p><strong>Адрес:</strong> г. Гродно, ул. Горького, 91</p>
            <p><strong>Телефон:</strong> +375 (29) 123-45-67</p>
            <p><strong>Email:</strong> info@suhofrukty-na-swage.by</p>
            <p><strong>Часы работы:</strong> Пн-Вс, 9:00–21:00</p>
        </div>
        <div class="map">
            <!-- Карта Google Maps для ул. Горького, 91, Гродно -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2359.766985669892!2d23.8258113161712!3d53.68613547994417!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46ddcfab6b3b2c1f%3A0x2e0e2a88e8d5d1c2!2z0J_QvtC70L7QtNC-0LLQsNC90LjRjw!5e0!3m2!1sru!2sby!4v1677654321!5m2!1sru!2sby" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="contact-form">
            <h2>ОСТАВЬ СООБЩЕНИЕ</h2>
            <form method="POST" action="send_contact.php"> <!-- Создадим send_contact.php позже -->
                <input type="text" name="name" placeholder="Твоё имя" required>
                <input type="email" name="email" placeholder="Твой email" required>
                <textarea name="message" placeholder="Твоё сообщение" rows="5" required></textarea>
                <input type="submit" value="ОТПРАВИТЬ">
            </form>
        </div>
    </div>
</body>
</html>