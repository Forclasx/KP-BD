<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>О НАС - СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body { 
            margin: 0; 
            padding: 0; 
            background: linear-gradient(45deg, #ff6b00, #ffcc00, #ff6b00); 
            font-family: 'Bebas Neue', sans-serif; 
            color: #fff; 
            overflow-x: hidden; 
            position: relative;
        }

        header { 
            background: rgba(0, 0, 0, 0.9); 
            padding: 20px; 
            text-align: center; 
            border-bottom: 3px solid #ff6b00; 
            box-shadow: 0 0 20px #ff6b00;
        }

        .logo { 
            font-size: 4em; 
            color: #ff6b00; 
            text-shadow: 5px 5px 10px #ffcc00; 
            font-weight: bold; 
            animation: pulse 2s infinite;
        }

        nav { 
            margin-top: 20px; 
        }
        nav a { 
            color: #ffcc00; 
            font-size: 1.5em; 
            margin: 0 20px; 
            text-decoration: none; 
            transition: color 0.3s; 
        }
        nav a:hover { 
            color: #ff6b00; 
        }

        .about-content { 
            max-width: 1000px; 
            margin: 20px auto; 
            background: rgba(0, 0, 0, 0.7); 
            padding: 40px; 
            border: 3px solid #ff6b00; 
            border-radius: 15px; 
            box-shadow: 0 0 30px #ff6b00;
        }
        .about-content h1 { 
            font-size: 4em; 
            text-align: center; 
            text-shadow: 0 0 15px #ffcc00; 
            margin-bottom: 20px; 
        }
        .about-content p { 
            font-size: 1.5em; 
            line-height: 1.6; 
            margin-bottom: 20px; 
        }
        .about-content img { 
            width: 100%; 
            max-width: 600px; 
            height: auto; 
            border-radius: 10px; 
            margin: 20px auto; 
            display: block; 
            box-shadow: 0 0 20px #ff6b00;
        }
        .map { 
            width: 100%; 
            height: 400px; 
            margin: 20px 0; 
            border: 3px solid #ff6b00; 
            border-radius: 15px; 
            box-shadow: 0 0 30px #ff6b00;
        }

        @keyframes pulse { 
            0% { transform: scale(1); } 
            50% { transform: scale(1.05); } 
            100% { transform: scale(1); } 
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</div>
        <nav>
            <a href="index.php">ГЛАВНАЯ</a>
            <a href="about.php">О НАС</a>
            <a href="contacts.php">КОНТАКТЫ</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="user_profile.php">ЛИЧНЫЙ КАБИНЕТ</a>
                <a href="logout_user.php">ВЫЙТИ (<?php echo $_SESSION['username']; ?>)</a>
            <?php else: ?>
                <a href="login_user.php">ВХОД</a>
                <a href="register.php">РЕГИСТРАЦИЯ</a>
            <?php endif; ?>
            <a href="admin.php">АДМИНКА</a>
        </nav>
    </header>

    <div class="about-content">
        <h1>О НАС - ПАЦАНЫ СУХОФРУКТОВ</h1>
        <p>Мы — команда пацанов, которые знают толк в сухофруктах! Наш магазин "Сухофрукты на высшем уровне" — это место, где ты найдёшь самые свежие, натуральные и вкусные сухофрукты для твоего драйва. С 2025 года мы радуем Гродно и всю Беларусь качеством и стилем!</p>
        <p>Наша миссия — приносить радость и энергию через вкусные сухофрукты. Мы закупаем только лучшее, чтобы ты чувствовал себя на высоте. Приходи к нам, закажи онлайн или просто зацени наш вайб!</p>
        
        <div class="map">
            <!-- Карта Google Maps для ул. Горького, 91, Гродно -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2359.766985669892!2d23.8258113161712!3d53.68613547994417!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46ddcfab6b3b2c1f%3A0x2e0e2a88e8d5d1c2!2z0J_QvtC70L7QtNC-0LLQsNC90LjRjw!5e0!3m2!1sru!2sby!4v1677654321!5m2!1sru!2sby" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <p>Наш магазин находится в самом сердце Гродно на ул. Горького, 91. Ждём тебя каждый день с 9:00 до 21:00!</p>
    </div>
</body>
</html>