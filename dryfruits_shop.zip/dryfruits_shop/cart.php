<?php
session_start();

// Подключение к базе данных
$conn = mysqli_connect("localhost", "root", "", "dryfruits_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $result = mysqli_query($conn, "SELECT * FROM products WHERE id = $product_id");
    $product = mysqli_fetch_assoc($result);
    
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    $_SESSION['cart'][] = [
        'name' => $product['name'],
        'price' => $product['price']
    ];
}

mysqli_close($conn);
header("Location: index.php");
exit();
?>