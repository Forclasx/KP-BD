<?php
require_once('tcpdf/TCPDF.php');

session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// Создаём новый PDF документ
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator('');
$pdf->SetTitle('Отчёт по заказам');
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Добавляем шрифт DejaVuSans с поддержкой кириллицы
$pdf->SetFont('dejavusans', '', 12, '', true);

// Добавляем страницу
$pdf->AddPage();

// Заголовок
$pdf->SetFont('dejavusans', 'B', 24);
$pdf->SetTextColor(255, 107, 0); // Оранжевый текст
$pdf->Cell(0, 20, 'ОТЧЁТ ПО ЗАКАЗАМ', 0, 1, 'C', false, '', 0, false, 'T', 'M');
$pdf->Ln(10);

// Стили для текста
$pdf->SetTextColor(255, 204, 0); // Жёлтый текст для основного контента
$pdf->SetDrawColor(255, 107, 0); // Оранжевая линия
$pdf->SetFillColor(0, 0, 0); // Чёрный фон для выделения

// Получаем все заказы
$order_result = mysqli_query($conn, "SELECT orders.id, orders.total_amount, orders.status, orders.created_at, orders.first_name, orders.last_name, orders.address, users.username 
    FROM orders 
    JOIN users ON orders.user_id = users.id 
    ORDER BY orders.created_at DESC");

$y = $pdf->GetY();
while ($order = mysqli_fetch_assoc($order_result)) {
    if ($y > 250) { // Начинаем новую страницу, если места мало
        $pdf->AddPage();
        $y = $pdf->GetY();
    }

    // Заголовок заказа
    $pdf->SetFont('dejavusans', 'B', 18);
    $pdf->Cell(0, 10, "Заказ #" . $order['id'], 0, 1, 'L', false, '', 0, false, 'T', 'M');
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY(), array('width' => 0.5, 'color' => array(255, 107, 0)));

    // Детали заказа
    $pdf->SetFont('dejavusans', '', 12);
    $pdf->Cell(0, 5, "Пользователь: " . $order['username'], 0, 1, 'L');
    $pdf->Cell(0, 5, "Имя: " . $order['first_name'], 0, 1, 'L');
    $pdf->Cell(0, 5, "Фамилия: " . $order['last_name'], 0, 1, 'L');
    $pdf->Cell(0, 5, "Адрес: " . $order['address'], 0, 1, 'L');
    $pdf->Cell(0, 5, "Сумма: " . $order['total_amount'] . " руб.", 0, 1, 'L');
    $pdf->Cell(0, 5, "Статус: " . $order['status'], 0, 1, 'L');
    $pdf->Cell(0, 5, "Дата: " . $order['created_at'], 0, 1, 'L');

    // Детали товаров в заказе
    $items_result = mysqli_query($conn, "SELECT order_items.quantity, products.name, order_items.price 
        FROM order_items 
        JOIN products ON order_items.product_id = products.id 
        WHERE order_items.order_id = " . $order['id']);
    $pdf->SetFont('dejavusans', 'B', 14);
    $pdf->Cell(0, 5, "Товары в заказе:", 0, 1, 'L');
    $pdf->SetFont('dejavusans', '', 12);
    while ($item = mysqli_fetch_assoc($items_result)) {
        $pdf->Cell(0, 5, $item['name'] . " - " . $item['quantity'] . " шт. - " . ($item['price'] * $item['quantity']) . " руб.", 0, 1, 'L');
    }
    $pdf->Ln(10);
    $y = $pdf->GetY();
}

// Вывод PDF для скачивания
$pdf->SetTextColor(255, 255, 255); // Белый текст для подписи
$pdf->SetFont('dejavusans', 'I', 10);
$pdf->Cell(0, 10, "", 0, 1, 'C');

$pdf->Output('orders_report.pdf', 'D');

mysqli_close($conn);
?>