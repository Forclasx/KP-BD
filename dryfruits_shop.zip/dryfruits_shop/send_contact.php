<?php
// Подключаемся к базе данных
$conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Здесь можно добавить отправку email (например, через PHPMailer для SMTP)
    // Для теста просто выведем сообщение и сохраним в базу
    echo "<p style='text-align: center; color: #ff6b00;'>Сообщение от $name отправлено! Мы скоро свяжемся с тобой, бро!</p>";

    // Сохраняем в таблицу contacts
    $query = "INSERT INTO contacts (name, email, message, created_at) VALUES ('$name', '$email', '$message', NOW())";
    if (mysqli_query($conn, $query)) {
        // Успешно сохранено
    } else {
        echo "<p style='text-align: center; color: red;'>Ошибка сохранения сообщения: " . mysqli_error($conn) . "</p>";
    }

    mysqli_close($conn);
} else {
    header("Location: contacts.php");
    exit();
}
?>