<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
    if (!$conn) {
        die("Ошибка подключения: " . mysqli_connect_error());
    }

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $error = "Такой логин или email уже есть, бро!";
    } else {
        $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if (mysqli_query($conn, $query)) {
            $_SESSION['user_id'] = mysqli_insert_id($conn);
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit();
        } else {
            $error = "Ошибка регистрации: " . mysqli_error($conn);
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>РЕГИСТРАЦИЯ ПАЦАНОВ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body {
            background: #000;
            color: #ffcc00;
            font-family: 'Bebas Neue', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .register-box {
            background: rgba(255, 107, 0, 0.2);
            padding: 40px;
            border: 3px solid #ff6b00;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 0 20px #ff6b00;
        }
        h1 { font-size: 3em; text-shadow: 0 0 10px #ff6b00; }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #333;
            border: 2px solid #ff6b00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
        }
        input[type="submit"] {
            background: #ff6b00;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        input[type="submit"]:hover { background: #ffcc00; color: #000; }
        p { color: red; }
    </style>
</head>
<body>
    <div class="register-box">
        <h1>РЕГИСТРАЦИЯ ПАЦАНОВ</h1>
        <form method="POST">
            <input type="text" name="username" placeholder="Логин" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="submit" value="ЗАРЕГАТЬСЯ">
        </form>
        <?php if (isset($error)) echo "<p>$error</p>"; ?>
        <p>Уже есть аккаунт? <a href="login_user.php" style="color: #ffcc00;">Войди, бро!</a></p>
    </div>
</body>
</html>