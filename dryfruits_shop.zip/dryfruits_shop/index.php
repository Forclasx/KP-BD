<?php
session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1; // По умолчанию user_id = 1 для гостей
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Roboto:wght@700&display=swap');

        body { 
            margin: 0; 
            padding: 0; 
            background: linear-gradient(45deg, #ff6b00, #ffcc00, #ff6b00); 
            font-family: 'Bebas Neue', sans-serif; 
            color: #fff; 
            overflow-x: hidden; 
            position: relative;
        }

        header { 
            background: rgba(0, 0, 0, 0.9); 
            padding: 20px; 
            text-align: center; 
            border-bottom: 3px solid #ff6b00; 
            box-shadow: 0 0 20px #ff6b00;
        }

        .logo { 
            font-size: 4em; 
            color: #ff6b00; 
            text-shadow: 5px 5px 10px #ffcc00; 
            font-weight: bold; 
            animation: pulse 2s infinite;
        }

        nav { 
            margin-top: 20px; 
        }
        nav a { 
            color: #ffcc00; 
            font-size: 1.5em; 
            margin: 0 20px; 
            text-decoration: none; 
            transition: color 0.3s; 
        }
        nav a:hover { 
            color: #ff6b00; 
        }

        .hero { 
            text-align: center; 
            padding: 50px 20px; 
            background: rgba(0, 0, 0, 0.7); 
            margin: 20px auto; 
            max-width: 1000px; 
            border-radius: 15px; 
            box-shadow: 0 0 30px #ff6b00;
        }
        .hero h1 { 
            font-size: 4.5em; 
            text-shadow: 0 0 15px #ffcc00; 
            margin-bottom: 20px; 
        }
        .hero p { 
            font-size: 1.5em; 
            line-height: 1.6; 
            margin-bottom: 30px; 
        }
        .hero button { 
            background: #ff6b00; 
            border: none; 
            padding: 15px 30px; 
            color: #fff; 
            font-size: 1.5em; 
            border-radius: 10px; 
            cursor: pointer; 
            transition: background 0.3s; 
        }
        .hero button:hover { 
            background: #ffcc00; 
            color: #000; 
        }

        .controls { 
            max-width: 1000px; 
            margin: 20px auto; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }
        .search-box, .sort-box { 
            background: rgba(255, 107, 0, 0.2); 
            padding: 10px; 
            border: 2px solid #ff6b00; 
            border-radius: 10px; 
        }
        input[type="text"], select { 
            padding: 10px; 
            background: #333; 
            border: 2px solid #ffcc00; 
            color: #fff; 
            font-size: 1.2em; 
            border-radius: 5px; 
        }
        input[type="submit"] { 
            background: #ff6b00; 
            border: none; 
            padding: 10px 20px; 
            color: #fff; 
            font-size: 1.2em; 
            border-radius: 10px; 
            cursor: pointer; 
            transition: background 0.3s; 
        }
        input[type="submit"]:hover { 
            background: #ffcc00; 
            color: #000; 
        }

        .products-container { 
            display: flex; 
            flex-wrap: wrap; 
            justify-content: center; 
            padding: 20px; 
            position: relative; 
            z-index: 10; 
        }
        .product { 
            background: rgba(0, 0, 0, 0.8); 
            border: 3px solid #ffcc00; 
            border-radius: 15px; 
            width: 250px; 
            margin: 15px; 
            padding: 20px; 
            text-align: center; 
            transition: transform 0.3s, box-shadow 0.3s; 
            box-shadow: 0 0 20px rgba(255, 204, 0, 0.5); 
        }
        .product:hover { 
            transform: scale(1.1) rotate(2deg); 
            box-shadow: 0 0 30px #ff6b00; 
        }
        .product img { 
            width: 100%; 
            height: 150px; 
            object-fit: cover; 
            border-radius: 10px; 
        }
        .product h3 { 
            font-size: 2em; 
            margin: 10px 0 0; 
            color: #ffcc00; 
            text-transform: uppercase; 
        }
        .product p { 
            font-size: 1.2em; 
            margin: 10px 0; 
            color: #fff; 
        }
        .product form input[type="number"] { 
            width: 50px; 
            padding: 5px; 
            border: none; 
            border-radius: 5px; 
            background: #fff; 
            color: #000; 
            font-weight: bold; 
        }

        .cart { 
            position: fixed; 
            right: 20px; 
            top: 100px; 
            background: rgba(0, 0, 0, 0.9); 
            border: 3px solid #ff6b00; 
            border-radius: 15px; 
            padding: 20px; 
            width: 250px; 
            box-shadow: 0 0 20px #ff6b00; 
            animation: float 3s infinite; 
            z-index: 10; 
        }
        .cart h2 { 
            font-size: 2.5em; 
            margin: 0 0 10px; 
            color: #ffcc00; 
        }
        .cart p { 
            font-size: 1.1em; 
            margin: 5px 0; 
            color: #fff; 
        }
        .clear-cart { 
            background: #ff0000; 
            margin-top: 10px; 
        }
        .clear-cart:hover { 
            background: #ff6666; 
        }

        .flying-fruit { 
            position: absolute; 
            width: 50px; 
            height: 50px; 
            background-size: contain; 
            background-repeat: no-repeat; 
            z-index: 5; 
            pointer-events: none; 
            animation: fly 5s infinite ease-in-out; 
        }
        footer { 
            background: rgba(0, 0, 0, 0.9); 
            padding: 20px; 
            text-align: center; 
            border-top: 3px solid #ff6b00; 
            box-shadow: 0 0 20px #ff6b00; 
            position: relative; 
            z-index: 10; 
        }
        footer p { 
            margin: 0; 
            font-size: 1.2em; 
            color: #ffcc00; 
        }

        .user-actions { 
            margin-top: 10px; 
            text-align: center; 
        }
        .user-actions a { 
            color: #ffcc00; 
            font-size: 1.2em; 
            margin: 0 10px; 
            text-decoration: none; 
        }
        .user-actions a:hover { 
            color: #ff6b00; 
        }

        @keyframes pulse { 
            0% { transform: scale(1); } 
            50% { transform: scale(1.05); } 
            100% { transform: scale(1); } 
        }
        @keyframes float { 
            0% { transform: translateY(0); } 
            50% { transform: translateY(-10px); } 
            100% { transform: translateY(0); } 
        }
        @keyframes fly { 
            0% { transform: translate(0, 0) rotate(0deg); } 
            25% { transform: translate(200px, -100px) rotate(90deg); } 
            50% { transform: translate(400px, 0) rotate(180deg); } 
            75% { transform: translate(200px, 100px) rotate(270deg); } 
            100% { transform: translate(0, 0) rotate(360deg); } 
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ</div>
        <nav>
            <a href="index.php">ГЛАВНАЯ</a>
            <a href="about.php">О НАС</a>
            <a href="contacts.php">КОНТАКТЫ</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="user_profile.php">ЛИЧНЫЙ КАБИНЕТ</a>
                <a href="logout_user.php">ВЫЙТИ (<?php echo $_SESSION['username']; ?>)</a>
            <?php else: ?>
                <a href="login_user.php">ВХОД</a>
                <a href="register.php">РЕГИСТРАЦИЯ</a>
            <?php endif; ?>
            <a href="admin.php">АДМИНКА</a>
        </nav>
    </header>

    <div class="hero">
        <h1>ЛУЧШИЕ СУХОФРУКТЫ ДЛЯ ПАЦАНОВ!</h1>
        <p>Только свежие, натуральные и вкусные сухофрукты для твоего драйва. Закажи прямо сейчас и почувствуй вкус свободы!</p>
        <button onclick="window.location.href='#products'">КУПИТЬ СЕЙЧАС</button>
    </div>

    <div class="controls">
        <div class="search-box">
            <form method="GET">
                <input type="text" name="search" placeholder="Поиск по названию" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <input type="submit" value="НАЙТИ">
            </form>
        </div>
        <div class="sort-box">
            <form method="GET">
                <select name="sort" onchange="this.form.submit()">
                    <option value="name_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_asc') ? 'selected' : ''; ?>>Название (А-Я)</option>
                    <option value="name_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'name_desc') ? 'selected' : ''; ?>>Название (Я-А)</option>
                    <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>Цена (по возрастанию)</option>
                    <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>Цена (по убыванию)</option>
                </select>
            </form>
        </div>
    </div>

    <div class="products-container" id="products">
    <?php
    $conn = mysqli_connect("localhost", "root", "", "dryfruits_shop_db");
    if (!$conn) {
        die("Ошибка подключения: " . mysqli_connect_error());
    }

    // Поиск и сортировка
    $where = "";
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = mysqli_real_escape_string($conn, $_GET['search']);
        $where = "WHERE name LIKE '%$search%'";
    }

    $order = "ORDER BY name ASC";
    if (isset($_GET['sort'])) {
        switch ($_GET['sort']) {
            case 'name_asc': $order = "ORDER BY name ASC"; break;
            case 'name_desc': $order = "ORDER BY name DESC"; break;
            case 'price_asc': $order = "ORDER BY price ASC"; break;
            case 'price_desc': $order = "ORDER BY price DESC"; break;
        }
    }

    $result = mysqli_query($conn, "SELECT * FROM products $where $order");
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='product'>";
        echo "<img src='" . ($row['image'] ?: 'images/default.png') . "' alt='" . $row['name'] . "'>";
        echo "<h3>" . $row['name'] . "</h3>";
        echo "<p>ЦЕНА: " . $row['price'] . " РУБ.</p>";
        echo "<p>НА СКЛАДЕ: " . $row['stock'] . "</p>";
        echo "<form method='POST' action='add_to_cart.php'>";
        echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
        echo "<input type='number' name='quantity' value='1' min='1' max='" . $row['stock'] . "'>";
        echo "<input type='submit' value='В КОРЗИНУ'>";
        echo "</form>";
        echo "</div>";
    }
    ?>
    </div>

    <div class="cart">
        <h2>КОРЗИНА</h2>
        <?php
        $cart_result = mysqli_query($conn, "SELECT cart.quantity, products.name, products.price 
            FROM cart 
            JOIN products ON cart.product_id = products.id 
            WHERE cart.user_id = $user_id");
        if (mysqli_num_rows($cart_result) > 0) {
            while ($cart_item = mysqli_fetch_assoc($cart_result)) {
                echo "<p>" . $cart_item['name'] . " - " . $cart_item['quantity'] . " ШТ. - " . ($cart_item['price'] * $cart_item['quantity']) . " РУБ.</p>";
            }
            echo "<form method='POST' action='clear_cart.php'>";
            echo "<input type='submit' value='ОЧИСТИТЬ КОРЗИНУ' class='clear-cart'>";
            echo "</form>";
            echo "<form method='POST' action='checkout.php'>";
            echo "<input type='submit' value='ОФОРМИТЬ ЗАКАЗ' style='background: #00ff00; margin-top: 10px;'>";
            echo "</form>";
        } else {
            echo "<p>КОРЗИНА ПУСТА, БРО</p>";
        }
        ?>
    </div>

    <?php
    $fruit_result = mysqli_query($conn, "SELECT image FROM products");
    $fruits = [];
    while ($fruit = mysqli_fetch_assoc($fruit_result)) {
        $fruits[] = $fruit['image'] ?: 'images/default.png';
    }
    for ($i = 0; $i < 5; $i++) { // Увеличили количество летающих фруктов
        $random_fruit = $fruits[array_rand($fruits)];
        echo "<div class='flying-fruit' style='background-image: url(\"$random_fruit\"); top: " . (10 + $i * 15) . "%; left: " . (10 + $i * 30) . "%; animation-delay: " . $i . "s;'></div>";
    }
    mysqli_close($conn);
    ?>

    <footer>
        <p>© 2025 СУХОФРУКТЫ НА ВЫСШЕМ УРОВНЕ | ВСЕ ПРАВА ЗАЩИЩЕНЫ</p>
    </footer>

    <audio id="fruit-sound" src="https://www.myinstants.com/media/sounds/fruit_drop.mp3"></audio>

    <script>
        document.querySelectorAll('input[type="submit"]').forEach(button => {
            button.addEventListener('click', () => {
                document.getElementById('fruit-sound').play();
            });
        });

        function spawnFruit() {
            const fruit = document.createElement('div');
            fruit.className = 'flying-fruit';
            const fruits = <?php echo json_encode($fruits); ?>;
            fruit.style.backgroundImage = `url(${fruits[Math.floor(Math.random() * fruits.length)]})`;
            fruit.style.top = `${Math.random() * 80}%`;
            fruit.style.left = `${Math.random() * 80}%`;
            fruit.style.animationDelay = `${Math.random() * 3}s`;
            document.body.appendChild(fruit);
            setTimeout(() => fruit.remove(), 5000);
        }

        setInterval(spawnFruit, 2000);
    </script>
</body>
</html>