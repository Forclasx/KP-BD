<?php
session_start();

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: admin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    
    $admin_username = "admin_bro";
    $admin_password = "ebanyi_fruit123";

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['logged_in'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error = "Неверный логин или пароль, бро!";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>ВХОД ДЛЯ БРО</title>
    <style>
        body {
            background: #000;
            color: #ffcc00;
            font-family: 'Bebas Neue', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-box {
            background: rgba(255, 107, 0, 0.2);
            padding: 40px;
            border: 3px solid #ff6b00;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 0 20px #ff6b00;
        }
        h1 { font-size: 3em; text-shadow: 0 0 10px #ff6b00; }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #333;
            border: 2px solid #ff6b00;
            color: #fff;
            font-size: 1.2em;
            border-radius: 5px;
        }
        input[type="submit"] {
            background: #ff6b00;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        input[type="submit"]:hover { background: #ffcc00; color: #000; }
        p { color: red; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>ВХОД ДЛЯ БРО</h1>
        <form method="POST">
            <input type="text" name="username" placeholder="Логин" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="submit" value="ЗАЙТИ">
        </form>
        <?php if (isset($error)) echo "<p>$error</p>"; ?>
    </div>
</body>
</html>